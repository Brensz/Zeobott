<br>
<p align="center"><img width="70%" src="https://telegra.ph/file/46b2e1b9b787ed3c42d02.png"></p>
<div align="center">

> if you use termux the sticker feature won't work.

<p>
  <img src ="https://img.shields.io/badge/npm-v7.20.3-green.svg" />
  <img src="https://img.shields.io/badge/node-%3E=17.x-darkgreen.svg" />
</p>

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/neoxr/neoxr-bot/)
</div>

### # FOR WINDOWS/VPS/RDP

* Instal Git [`Click Here`](https://git-scm.com/downloads)
* Instal NodeJS [`Click Here`](https://nodejs.org/en/download)
* Instal FFmpeg [`Click Here`](https://ffmpeg.org/download.html)

### # FOR HEROKU (BUILDPACK)

* heroku/nodejs
* https://github.com/neoxr/heroku-buildpack-ffmpeg-latest

### # GET STARTED ⬇️

```bash
> git clone https://github.com/neoxr/neoxr-bot/
> cd neoxr-bot
> npm i
```
### # RUN

```bash
> npm . <sesson_name>
```

### # THANKS TO

* <a href="https://github.com/adiwajshing/Baileys"><img alt="GitHub" src="https://img.shields.io/badge/@adiwajshing/Baileys%20-%23121011.svg?style=flat-square&logo=npm&color=white"/></a>
